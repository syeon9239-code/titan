# 타이탄클래스 (TitanClass) Frontend

타이탄클래스(titanclass.co.kr) 웹사이트 프론트엔드 재구현입니다.

## 기술 스택

- **Next.js 14** (Pages Router)
- **React 18** + **TypeScript**
- **TailwindCSS 3**

## 시작하기

### 1. 의존성 설치

```bash
npm install
```

### 2. 개발 서버 실행

```bash
npm run dev
```

브라우저에서 [http://localhost:3000](http://localhost:3000) 열기

### 3. 프로덕션 빌드

```bash
npm run build
npm run start
```

## 배포 (Vercel 권장)

```bash
# Vercel CLI 설치
npm i -g vercel

# 배포
vercel
```

또는 GitHub에 push 후 [vercel.com](https://vercel.com)에서 레포 연결하면 자동 배포됩니다.

## 프로젝트 구조

```
titanclass/
├── pages/
│   ├── _app.tsx          # 글로벌 설정
│   └── index.tsx         # 메인 페이지 (SPA 라우팅)
├── components/
│   ├── TopNav.tsx         # 상단 유틸리티 네비
│   ├── Header.tsx         # 메인 헤더
│   ├── Footer.tsx         # 푸터 + 마퀴
│   ├── FireworksHero.tsx  # Canvas 폭죽 배너
│   ├── CourseCard.tsx     # 강의 카드
│   ├── SectionHeader.tsx  # 섹션 헤더
│   ├── KakaoLoginOverlay.tsx  # 카카오 로그인 애니메이션
│   └── pages/
│       ├── HomePage.tsx        # 홈
│       ├── CoursesPage.tsx     # 클래스 목록 (탭: 전체/무료/프리미엄/VOD)
│       ├── FreeDetailPage.tsx  # 무료강의 상세
│       ├── LoginPage.tsx       # 로그인
│       └── MyPage.tsx          # 마이페이지
├── data/
│   └── mockData.ts        # 목업 데이터 (강의, 강사, 후기 등)
├── styles/
│   └── globals.css        # 글로벌 스타일 + Tailwind
├── tailwind.config.ts
├── tsconfig.json
├── next.config.js
└── package.json
```

## 주요 기능

- 🎆 **폭죽 Hero 배너** — Canvas API 실시간 렌더링 (국화/모란/버드나무/크로세트 4종)
- 🔐 **카카오 로그인** — 3단계 애니메이션 후 자동 마이페이지 이동
- 📚 **강의 목록** — 무료/프리미엄/VOD 탭 필터
- 👤 **마이페이지** — 내 강의실 (수강중/완료/전체)
- 📅 **2월 강의 캘린더**
- 🔁 **마퀴 YOUR SUCCESS** 배너
