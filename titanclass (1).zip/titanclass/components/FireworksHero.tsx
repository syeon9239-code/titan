'use client'
import React, { useEffect, useRef } from 'react'

interface FireworksHeroProps {
  onNavigate: (page: string) => void
}

export default function FireworksHero({ onNavigate }: FireworksHeroProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')!

    function resize() {
      canvas!.width  = canvas!.offsetWidth
      canvas!.height = canvas!.offsetHeight
    }
    resize()
    window.addEventListener('resize', resize)

    // Palettes: gold / copper / silver-blue / red-gold
    const PALETTES: number[][][] = [
      [[255,240,180],[255,220,120],[255,200,80],[255,255,220]],
      [[255,180,60],[255,140,40],[255,200,100],[255,230,160]],
      [[200,220,255],[160,200,255],[255,255,255],[220,240,255]],
      [[255,100,60],[255,180,80],[255,240,140],[255,60,30]],
    ]

    class Spark {
      x: number; y: number; px: number; py: number
      col: number[]; vx: number; vy: number
      alpha: number; life: number; decay: number
      gravity: number; thickness: number; flicker: boolean

      constructor(ox: number, oy: number, col: number[], angle: number, speed: number) {
        this.x = ox; this.y = oy; this.px = ox; this.py = oy
        this.col = col
        this.vx = Math.cos(angle) * speed
        this.vy = Math.sin(angle) * speed
        this.alpha = 1; this.life = 1
        this.decay = 0.016 + Math.random() * 0.012
        this.gravity = 0.09 + Math.random() * 0.07
        this.thickness = 0.8 + Math.random() * 1.4
        this.flicker = Math.random() > 0.55
      }

      update() {
        this.px = this.x; this.py = this.y
        this.vx *= 0.978; this.vy *= 0.978; this.vy += this.gravity
        this.x += this.vx; this.y += this.vy
        this.life -= this.decay
        this.alpha = this.life * (this.flicker ? 0.6 + Math.random() * 0.4 : 1)
      }

      draw(ctx: CanvasRenderingContext2D) {
        if (this.life <= 0) return
        const [r, g, b] = this.col
        const grad = ctx.createLinearGradient(this.x, this.y, this.px, this.py)
        grad.addColorStop(0, `rgba(${r},${g},${b},${this.alpha})`)
        grad.addColorStop(0.35, `rgba(${Math.min(255,r+60)},${Math.min(255,g+60)},${Math.min(255,b+40)},${this.alpha*0.7})`)
        grad.addColorStop(1, `rgba(${r},${g},${b},0)`)

        ctx.save()
        ctx.beginPath()
        ctx.moveTo(this.x, this.y); ctx.lineTo(this.px, this.py)
        ctx.strokeStyle = grad; ctx.lineWidth = this.thickness * this.life; ctx.lineCap = 'round'
        ctx.stroke()

        if (this.life > 0.3) {
          const r2 = this.thickness * 2.5 * this.life
          const glow = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, r2 * 3)
          glow.addColorStop(0, `rgba(255,255,${Math.min(255,b+100)},${this.alpha*0.9})`)
          glow.addColorStop(0.4, `rgba(${r},${g},${b},${this.alpha*0.4})`)
          glow.addColorStop(1, `rgba(${r},${g},${b},0)`)
          ctx.beginPath(); ctx.arc(this.x, this.y, r2*3, 0, Math.PI*2)
          ctx.fillStyle = glow; ctx.fill()
        }
        ctx.restore()
      }
    }

    class Firework {
      x: number; y: number; tx: number; ty: number
      vx: number; vy: number; trail: {x:number,y:number}[]
      exploded: boolean; sparks: Spark[]
      palette: number[][]; burstRadius: number
      sparkCount: number; type: number

      constructor(W: number, H: number) {
        this.x = W * (0.08 + Math.random() * 0.84)
        this.y = H + 8
        this.ty = H * (0.05 + Math.random() * 0.52)
        this.tx = W * (0.05 + Math.random() * 0.9)
        const dx = this.tx - this.x, dy = this.ty - this.y
        const d = Math.sqrt(dx*dx + dy*dy)
        const sp = 10 + Math.random() * 10
        this.vx = (dx/d)*sp; this.vy = (dy/d)*sp
        this.trail = []; this.exploded = false; this.sparks = []
        this.palette = PALETTES[Math.floor(Math.random()*PALETTES.length)]
        this.burstRadius = 7 + Math.random() * 6
        this.sparkCount  = 220 + Math.floor(Math.random() * 160)
        this.type = Math.random()
      }

      update(W: number, H: number) {
        if (!this.exploded) {
          this.trail.push({x:this.x, y:this.y})
          if (this.trail.length > 18) this.trail.shift()
          this.vy += 0.22; this.x += this.vx; this.y += this.vy
          if (this.vy >= -0.5 || this.y <= this.ty) this.burst()
        } else {
          this.sparks.forEach(s => s.update())
          this.sparks = this.sparks.filter(s => s.life > 0)
        }
      }

      burst() {
        this.exploded = true
        const N = this.sparkCount, pal = this.palette, br = this.burstRadius, t = this.type

        if (t < 0.40) {
          // Chrysanthemum
          for (let i = 0; i < N; i++) {
            const angle = (i/N)*Math.PI*2 + (Math.random()-0.5)*0.08
            const outer = Math.random() > 0.28
            const speed = outer ? br*(0.85+Math.random()*0.3) : br*(0.2+Math.random()*0.3)
            const col   = pal[Math.floor(Math.random()*pal.length)]
            const s = new Spark(this.x, this.y, col, angle, speed)
            if (!outer) { s.decay *= 1.6; s.thickness *= 0.7 }
            this.sparks.push(s)
          }
        } else if (t < 0.65) {
          // Peony
          for (let i = 0; i < N; i++) {
            const angle = (i/N)*Math.PI*2
            const speed = br*(0.6+Math.random()*0.5)
            const s = new Spark(this.x, this.y, pal[i%pal.length], angle, speed)
            s.decay *= 0.85; s.gravity *= 0.75; this.sparks.push(s)
          }
        } else if (t < 0.80) {
          // Willow
          for (let i = 0; i < N; i++) {
            const angle = (i/N)*Math.PI*2 + (Math.random()-0.5)*0.05
            const speed = br*(0.9+Math.random()*0.4)
            const s = new Spark(this.x, this.y, pal[0], angle, speed)
            s.gravity *= 2.2; s.decay *= 0.65; s.thickness *= 1.3; this.sparks.push(s)
          }
        } else {
          // Crossette clusters
          const CLUSTERS = 6 + Math.floor(Math.random()*4)
          for (let c = 0; c < CLUSTERS; c++) {
            const baseAngle = (c/CLUSTERS)*Math.PI*2
            const baseSpeed = br*(0.6+Math.random()*0.4)
            const cx = this.x + Math.cos(baseAngle)*baseSpeed*8
            const cy = this.y + Math.sin(baseAngle)*baseSpeed*8
            const subN = Math.floor(N/CLUSTERS)
            for (let i = 0; i < subN; i++) {
              const angle = baseAngle + (Math.random()-0.5)*1.2
              this.sparks.push(new Spark(cx, cy, pal[c%pal.length], angle, br*0.5*(0.4+Math.random()*0.6)))
            }
          }
        }

        // Gold glitter core
        for (let i = 0; i < 60; i++) {
          const s = new Spark(this.x, this.y, [255,255,200], Math.random()*Math.PI*2, Math.random()*br*0.35)
          s.decay *= 1.8; s.thickness = 2.5; this.sparks.push(s)
        }
      }

      draw(ctx: CanvasRenderingContext2D) {
        if (!this.exploded) {
          this.trail.forEach((pt, i) => {
            const a = (i/this.trail.length)*0.85
            ctx.beginPath(); ctx.arc(pt.x, pt.y, 2*(i/this.trail.length), 0, Math.PI*2)
            ctx.fillStyle = `rgba(255,220,140,${a})`; ctx.fill()
          })
          const g = ctx.createRadialGradient(this.x,this.y,0,this.x,this.y,10)
          g.addColorStop(0,'rgba(255,255,200,1)'); g.addColorStop(0.4,'rgba(255,200,80,0.6)'); g.addColorStop(1,'rgba(255,150,40,0)')
          ctx.beginPath(); ctx.arc(this.x,this.y,10,0,Math.PI*2); ctx.fillStyle=g; ctx.fill()
        } else {
          this.sparks.forEach(s => s.draw(ctx))
          const avgLife = this.sparks.length > 0 ? this.sparks.reduce((a,s)=>a+s.life,0)/this.sparks.length : 0
          if (avgLife > 0.80) {
            const flash = (avgLife-0.80)/0.20
            const fr = ctx.createRadialGradient(this.x,this.y,0,this.x,this.y,80)
            fr.addColorStop(0, `rgba(255,255,255,${flash*0.9})`); fr.addColorStop(0.3,`rgba(255,240,180,${flash*0.5})`); fr.addColorStop(1,'rgba(255,200,80,0)')
            ctx.beginPath(); ctx.arc(this.x,this.y,80,0,Math.PI*2); ctx.fillStyle=fr; ctx.fill()
          }
        }
      }

      isDead() { return this.exploded && this.sparks.length === 0 }
    }

    let fireworks: Firework[] = []
    let lastLaunch = 0
    let rafId: number

    function launch(W: number, H: number) {
      fireworks.push(new Firework(W, H))
      if (Math.random() > 0.45) fireworks.push(new Firework(W, H))
    }

    function loop(now: number) {
      const W = canvas!.width, H = canvas!.height
      ctx.fillStyle = 'rgba(0,0,0,0.14)'
      ctx.fillRect(0, 0, W, H)
      if (now - lastLaunch > 700 + Math.random()*500) { launch(W,H); lastLaunch = now }
      if (fireworks.length < 2) launch(W, H)
      fireworks.forEach(f => { f.update(W,H); f.draw(ctx) })
      fireworks = fireworks.filter(f => !f.isDead())
      rafId = requestAnimationFrame(loop)
    }

    const W0 = canvas.width, H0 = canvas.height
    for (let i = 0; i < 2; i++) fireworks.push(new Firework(W0, H0))
    rafId = requestAnimationFrame(loop)

    return () => {
      window.removeEventListener('resize', resize)
      cancelAnimationFrame(rafId)
    }
  }, [])

  return (
    <div className="relative w-full h-[420px] overflow-hidden bg-black">
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
      {/* Overlay */}
      <div className="pointer-events-none absolute inset-0"
        style={{ background: 'linear-gradient(to right, rgba(0,0,0,0.72) 0%, rgba(0,0,0,0.28) 55%, rgba(0,0,0,0.05) 100%)' }} />
      {/* Content */}
      <div className="absolute inset-0 z-10 flex items-center px-20">
        <div>
          <p className="mb-[10px] text-[13px] tracking-[2px] uppercase text-white/65">TITAN CLASS</p>
          <h1 className="mb-3 text-[44px] font-black leading-tight text-white">
            당신의 성공을 위한<br />최고의 강의
          </h1>
          <p className="mb-7 text-[15px] text-white/70">엄노직업 수익화 전문가들의 실전 노하우를 배워보세요</p>
          <div className="flex gap-3">
            <button
              onClick={() => onNavigate('free')}
              className="rounded-md bg-[#cc0000] px-[30px] py-[13px] text-sm font-bold text-white hover:bg-[#aa0000] transition-colors"
            >
              🔥 무료강의 보기
            </button>
            <button
              onClick={() => onNavigate('courses')}
              className="rounded-md border border-white/40 bg-white/[0.12] px-[30px] py-[13px] text-sm text-white backdrop-blur-sm hover:bg-white/[0.22] transition-colors"
            >
              전체 클래스
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
