import React from 'react'

interface HeaderProps {
  isLoggedIn: boolean
  onNavigate: (page: string) => void
  onLogout: () => void
}

const NAV_LINKS = ['클래스', '타이탄', '전자책', '강사진', '고객센터']

export default function Header({ isLoggedIn, onNavigate, onLogout }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 flex h-[60px] items-center gap-8 border-b border-gray-200 bg-white px-10">
      {/* Logo */}
      <button
        onClick={() => onNavigate('home')}
        className="flex items-center gap-2 shrink-0"
      >
        <div
          className="w-8 h-8 bg-[#cc0000]"
          style={{ clipPath: 'polygon(0 0,100% 0,100% 70%,50% 100%,0 70%)' }}
        />
        <span className="text-lg font-black tracking-tight">
          TITAN<span className="text-[#cc0000]">CLASS</span>
        </span>
      </button>

      {/* Main nav */}
      <nav className="flex">
        {NAV_LINKS.map((label) => (
          <button
            key={label}
            onClick={() => onNavigate(label === '클래스' ? 'courses' : 'home')}
            className="flex h-[60px] items-center px-[18px] text-[15px] font-medium text-gray-800 hover:text-[#cc0000] transition-colors"
          >
            {label}
          </button>
        ))}
      </nav>

      {/* Right side */}
      <div className="ml-auto flex items-center gap-3">
        {isLoggedIn ? (
          <>
            <button
              onClick={() => onNavigate('mypage')}
              className="flex items-center gap-2 rounded-full bg-gray-100 px-3 py-1 text-sm font-medium hover:bg-gray-200 transition-colors"
            >
              <div className="flex h-7 w-7 items-center justify-center rounded-full bg-[#cc0000] text-sm text-white font-bold">
                박
              </div>
              박시연
            </button>
            <button
              onClick={onLogout}
              className="rounded bg-gray-100 px-4 py-[7px] text-sm text-gray-600 hover:bg-gray-200 transition-colors"
            >
              로그아웃
            </button>
          </>
        ) : (
          <>
            <div className="flex items-center gap-2 rounded border border-gray-300 px-3 py-[5px]">
              <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24" className="text-gray-400">
                <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
              </svg>
              <input
                type="text"
                placeholder="찾으시는 강사/과정명을 입력해보세요..."
                className="w-44 text-xs outline-none font-[inherit]"
              />
            </div>
            <button
              onClick={() => onNavigate('login')}
              className="rounded bg-[#cc0000] px-4 py-[7px] text-sm font-medium text-white hover:bg-[#aa0000] transition-colors"
            >
              로그인
            </button>
          </>
        )}
      </div>
    </header>
  )
}
