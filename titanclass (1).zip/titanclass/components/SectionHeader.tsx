import React from 'react'

interface SectionHeaderProps {
  icon?: string
  title: string
  sub?: string
  showNav?: boolean
}

export default function SectionHeader({ icon, title, sub, showNav = true }: SectionHeaderProps) {
  return (
    <div className="mb-6 flex items-center justify-between">
      <h2 className="flex items-center gap-2 text-xl font-bold">
        {icon && <span>{icon}</span>}
        {title}
        {sub && <span className="text-sm font-normal text-gray-400 ml-1">{sub}</span>}
      </h2>
      {showNav && (
        <div className="flex gap-1.5">
          <button className="flex h-7 w-7 items-center justify-center rounded-full border border-gray-200 bg-white text-sm hover:bg-gray-50">‹</button>
          <button className="flex h-7 w-7 items-center justify-center rounded-full border border-gray-200 bg-white text-sm hover:bg-gray-50">›</button>
        </div>
      )}
    </div>
  )
}
