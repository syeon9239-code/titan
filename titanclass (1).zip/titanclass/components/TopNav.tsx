import React from 'react'

interface TopNavProps {
  onNavigate: (page: string) => void
}

const TOP_LINKS = [
  { label: '무료강의',    page: 'free' },
  { label: '프리미엄강의', page: 'premium' },
  { label: 'VOD 강의',   page: 'vod' },
  { label: '전자책',      page: 'home' },
  { label: '강사진',      page: 'home' },
]

export default function TopNav({ onNavigate }: TopNavProps) {
  return (
    <nav className="flex h-9 border-b border-gray-200 bg-white">
      {TOP_LINKS.map((link, i) => (
        <button
          key={link.label}
          onClick={() => onNavigate(link.page)}
          className={`flex flex-1 items-center justify-center text-xs text-gray-500 hover:text-red-700 transition-colors whitespace-nowrap px-2 ${
            i < TOP_LINKS.length - 1 ? 'border-r border-gray-200' : ''
          }`}
        >
          {link.label}
        </button>
      ))}
    </nav>
  )
}
