import React, { useState } from 'react'
import CourseCard from '../CourseCard'
import SectionHeader from '../SectionHeader'
import { FREE_COURSES, PREMIUM_COURSES, VOD_COURSES, Course } from '../../data/mockData'

interface CoursesPageProps {
  onNavigate: (page: string) => void
  initialTab?: 'all' | 'free' | 'premium' | 'vod'
}

const TABS = [
  { id: 'all',     label: '전체' },
  { id: 'free',    label: '무료강의' },
  { id: 'premium', label: '프리미엄강의' },
  { id: 'vod',     label: 'VOD강의' },
]

export default function CoursesPage({ onNavigate, initialTab = 'all' }: CoursesPageProps) {
  const [tab, setTab] = useState<string>(initialTab)

  const showFree    = tab === 'all' || tab === 'free'
  const showPremium = tab === 'all' || tab === 'premium'
  const showVod     = tab === 'all' || tab === 'vod'

  return (
    <div>
      {/* Sub hero */}
      <div className="bg-gradient-to-br from-[#1a1a2e] to-[#cc0000]/50 py-10">
        <div className="mx-auto max-w-[1200px] px-10">
          <p className="text-[13px] text-white/60 mb-1">지금 만무우인</p>
          <h1 className="text-[28px] font-black text-white">클래스</h1>
        </div>
      </div>

      <div className="mx-auto max-w-[1200px] px-10">
        {/* Tabs */}
        <div className="mb-0 flex border-b-2 border-gray-200">
          {TABS.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`px-6 py-3.5 text-[15px] font-medium border-b-2 -mb-0.5 transition-colors ${
                tab === t.id
                  ? 'border-[#cc0000] text-[#cc0000]'
                  : 'border-transparent text-gray-500 hover:text-gray-800'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {showFree && (
          <section className="py-12">
            <SectionHeader icon="🔥" title="무료 강의" sub="Webinar" />
            <div className="grid grid-cols-3 gap-5">
              {FREE_COURSES.map(c => (
                <CourseCard key={c.id} course={c} onClick={() => onNavigate('free-detail')} />
              ))}
            </div>
          </section>
        )}

        {/* Gift Banner */}
        {(tab === 'all') && (
          <div className="mb-12 flex items-center justify-between rounded-xl px-10 py-7"
            style={{background:'linear-gradient(135deg,#1a1a2e,#0f3460)'}}>
            <div className="text-white">
              <h3 className="text-[18px] font-bold leading-snug">첫 만남 수강생 한정<br/>타이탄클래스가 준비한 특별 선물</h3>
            </div>
            <button className="rounded-md bg-[#cc0000] px-6 py-2.5 text-sm font-semibold text-white hover:bg-[#aa0000] transition-colors">
              지금 받기 →
            </button>
          </div>
        )}

        {showPremium && (
          <section className={tab !== 'all' ? 'py-12' : 'pb-12'}>
            <SectionHeader icon="🎁" title="프리미엄 강의" sub="Premium Lecture" />
            <div className="max-w-[400px]">
              {PREMIUM_COURSES.map(c => (
                <CourseCard key={c.id} course={c} />
              ))}
            </div>
          </section>
        )}

        {showVod && (
          <section className={tab !== 'all' ? 'py-12' : 'pb-12'}>
            <SectionHeader icon="🔥" title="바로 들을 수 있는, VOD강의" sub="VOD Lecture" />
            <div className="grid grid-cols-2 gap-5">
              {VOD_COURSES.map(c => (
                <CourseCard key={c.id} course={c} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  )
}
