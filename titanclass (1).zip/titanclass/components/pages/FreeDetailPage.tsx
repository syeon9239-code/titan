import React from 'react'
import CourseCard from '../CourseCard'
import { FREE_COURSES } from '../../data/mockData'

interface FreeDetailPageProps {
  onNavigate: (page: string) => void
}

export default function FreeDetailPage({ onNavigate }: FreeDetailPageProps) {
  const course = FREE_COURSES[0]

  return (
    <div>
      {/* Sub tabs */}
      <div className="border-b border-gray-200 bg-white px-10">
        <div className="flex">
          {['전체','무료강의','프리미엄강의','VOD강의'].map((t,i) => (
            <button key={t} onClick={() => onNavigate(i===0?'courses':i===1?'free':'courses')}
              className={`px-6 py-3.5 text-[15px] font-medium border-b-2 -mb-0.5 ${i===1?'border-[#cc0000] text-[#cc0000]':'border-transparent text-gray-500 hover:text-gray-800'}`}>
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="mx-auto max-w-[1200px] px-10">
        {/* Breadcrumb */}
        <div className="py-3 text-[12px] text-gray-400">
          <button onClick={() => onNavigate('home')} className="hover:text-[#cc0000]">홈</button>
          <span className="mx-1">›</span>
          <button onClick={() => onNavigate('courses')} className="hover:text-[#cc0000]">클래스 목록</button>
          <span className="mx-1">›</span>
          <button onClick={() => onNavigate('free')} className="hover:text-[#cc0000]">무료강의</button>
          <span className="mx-1">›</span>
          <span className="text-gray-600">{course.title}</span>
        </div>

        <div className="grid grid-cols-[1fr_340px] gap-10 py-6">
          {/* Left */}
          <div>
            {/* Hero thumbnail */}
            <div className={`mb-6 flex aspect-video w-full flex-col items-center justify-center rounded-xl bg-gradient-to-br ${course.gradClass} px-6 text-center text-white`}>
              <span className="mb-3 rounded bg-green-600 px-2 py-0.5 text-[11px] font-bold">무료강의</span>
              <p className="mb-2 text-[13px] text-white/70">{course.date}</p>
              <h2 className="text-3xl font-black leading-snug whitespace-pre-line">{course.shortTitle}</h2>
              <p className="mt-3 text-[13px] text-white/70">{course.instructor}</p>
            </div>

            {/* Content tabs */}
            <div className="mb-6 flex border-b-2 border-gray-200">
              {['콘텐츠 소개','강사 소개'].map((t,i) => (
                <a key={t} href="#" className={`px-5 py-3 text-[14px] font-medium border-b-2 -mb-0.5 ${i===0?'border-[#cc0000] text-[#cc0000]':'border-transparent text-gray-500'}`}>{t}</a>
              ))}
            </div>

            {/* Content body */}
            <div className="pb-10">
              <div className="mb-6 rounded-xl p-12 text-center text-white"
                style={{background:'linear-gradient(135deg,#0d1117,#1a1a2e)'}}>
                <h3 className="mb-4 text-2xl font-black leading-snug" style={{color:'#ccff00'}}>무료 강의 신청하시는<br/>모든 분들께 제공!</h3>
                <p className="mb-6 text-[14px] text-white/60">라이브 날짜 | 2월 22일 (일) 저녁 7시30분</p>
                <div className="mb-4 rounded-lg bg-white/5 p-6">
                  <p className="mb-1 text-[12px] text-white/40">월 천 만원 만든</p>
                  <h4 className="text-xl font-black">실전 기록 ①</h4>
                  <p className="mt-2 text-[11px] text-white/40">영화·드라마 유튜브 쇼츠 노하우</p>
                </div>
                <h3 className="mb-4 mt-6 text-2xl font-black leading-snug" style={{color:'#ccff00'}}>무료 강의 끝까지<br/>시청하시는 분들께 제공!</h3>
                <div className="rounded-lg bg-white/5 p-6">
                  <p className="mb-1 text-[12px] text-white/40">월 천 만원 만든</p>
                  <h4 className="text-xl font-black">실전 기록 ②</h4>
                  <p className="mt-2 text-[11px] text-white/40">영화·드라마 유튜브 쇼츠 노하우</p>
                </div>
              </div>

              {/* Instructor */}
              <h3 className="mb-4 text-[16px] font-bold">강사 소개</h3>
              <div className="mb-6 flex items-center gap-3 rounded-lg bg-gray-50 p-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#cc0000] text-xl">👨</div>
                <div>
                  <p className="font-semibold">{course.instructor}</p>
                  <p className="text-[12px] text-gray-500">마케팅 수익 전문가</p>
                </div>
                <button className="ml-auto flex h-7 w-7 items-center justify-center rounded-full border border-gray-200 text-base">+</button>
              </div>
              <div className="text-[14px] leading-relaxed text-gray-600">
                <p className="mb-3 font-semibold text-gray-800">마케팅 수익 전문가</p>
                <p className="mb-4">부업으로 시작해서 전업으로 월 천만원 이상의 수익을 내고 있는 전문 강사입니다. 유튜브 쇼츠 기반으로 5억 이상 벌었습니다.</p>
                <p className="mb-3 font-semibold text-gray-800">연락조항</p>
                <ul className="space-y-1.5">
                  <li>✓ 직업이 100% 없는 유튜브파워인입니다.</li>
                  <li>✓ 제이파: 연령 5만 달러 이상, 월 소득 5만 이상, 월 소득 3천 이상 달성했습니다.</li>
                  <li>✓ 강의 중점: 이론보다 전략 노하우, 실전 중점 강의로 바로 실행할 수 있게 전달드립니다.</li>
                  <li>✓ 수강생 성과: 사람들도 매달 월 천만원 이상 달성한 수강생이 많이 배출되어 인연을 경험했습니다.</li>
                </ul>
              </div>

              {/* Related */}
              <div className="mt-12">
                <h3 className="mb-4 flex items-center gap-2 text-[16px] font-bold">
                  <span className="text-[#cc0000]">🔥</span> 이런 강의는 어때요?
                </h3>
                <div className="grid grid-cols-3 gap-4">
                  {FREE_COURSES.slice(3, 6).map(c => (
                    <CourseCard key={c.id} course={c} onClick={() => onNavigate('free-detail')} />
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="sticky top-[80px] self-start">
            <div className="rounded-lg border border-gray-200 p-5">
              <div className="mb-2.5 flex gap-1.5">
                {course.badges.map(b => (
                  <span key={b} className={`rounded px-1.5 py-0.5 text-[11px] font-bold text-white ${b==='HOT'?'bg-[#cc0000]':'bg-orange-500'}`}>{b}</span>
                ))}
              </div>
              <p className="mb-4 text-[16px] font-bold leading-snug">{course.title}</p>
              <div className="mb-2 flex gap-2 text-[13px]">
                <span className="text-gray-400">강사</span>
                <span className="font-semibold">{course.instructor}</span>
              </div>
              <div className="mb-3 flex items-center gap-2 text-[13px]">
                <span className="text-gray-400">무료강의일</span>
                <span className="font-semibold text-[#cc0000]">2/22 (일) 19시 30분</span>
              </div>
              <p className="mb-3 text-[12px] text-gray-500">무료강의시간 <span className="font-semibold text-gray-700">68시간 00분 18초</span></p>
              <button
                onClick={() => onNavigate('login')}
                className="mt-3 w-full rounded-lg bg-[#cc0000] py-3.5 text-[16px] font-bold text-white hover:bg-[#aa0000] transition-colors"
              >
                무료강의 신청하기 →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
