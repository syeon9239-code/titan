import React, { useState, useCallback } from 'react'
import type { NextPage } from 'next'
import Head from 'next/head'

import TopNav from '../components/TopNav'
import Header from '../components/Header'
import Footer from '../components/Footer'
import KakaoLoginOverlay from '../components/KakaoLoginOverlay'

import HomePage from '../components/pages/HomePage'
import CoursesPage from '../components/pages/CoursesPage'
import FreeDetailPage from '../components/pages/FreeDetailPage'
import LoginPage from '../components/pages/LoginPage'
import MyPage from '../components/pages/MyPage'

type PageId = 'home' | 'courses' | 'free' | 'premium' | 'vod' | 'free-detail' | 'login' | 'mypage'

const Home: NextPage = () => {
  const [page, setPage] = useState<PageId>('home')
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [showKakao, setShowKakao] = useState(false)

  const navigate = useCallback((p: string) => {
    window.scrollTo(0, 0)
    setPage(p as PageId)
  }, [])

  const handleKakaoLogin = useCallback(() => {
    setShowKakao(true)
  }, [])

  const handleLoginComplete = useCallback(() => {
    setShowKakao(false)
    setIsLoggedIn(true)
    navigate('mypage')
  }, [navigate])

  const handleLogout = useCallback(() => {
    setIsLoggedIn(false)
    navigate('home')
  }, [navigate])

  return (
    <>
      <Head>
        <title>타이탄클래스 - TITAN CLASS</title>
        <meta name="description" content="당신의 성공을 위한 최고의 강의 - 타이탄클래스" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      {/* Kakao overlay */}
      {showKakao && (
        <KakaoLoginOverlay
          onComplete={handleLoginComplete}
          onClose={() => setShowKakao(false)}
        />
      )}

      {/* Chrome */}
      <TopNav onNavigate={navigate} />
      <Header isLoggedIn={isLoggedIn} onNavigate={navigate} onLogout={handleLogout} />

      {/* Pages */}
      <main>
        {page === 'home'        && <HomePage       onNavigate={navigate} />}
        {page === 'courses'     && <CoursesPage    onNavigate={navigate} initialTab="all" />}
        {page === 'free'        && <CoursesPage    onNavigate={navigate} initialTab="free" />}
        {page === 'premium'     && <CoursesPage    onNavigate={navigate} initialTab="premium" />}
        {page === 'vod'         && <CoursesPage    onNavigate={navigate} initialTab="vod" />}
        {page === 'free-detail' && <FreeDetailPage onNavigate={navigate} />}
        {page === 'login'       && <LoginPage      onKakaoLogin={handleKakaoLogin} />}
        {page === 'mypage'      && <MyPage         onNavigate={navigate} onLogout={handleLogout} />}
      </main>

      {/* Footer (not on login) */}
      {page !== 'login' && <Footer />}
    </>
  )
}

export default Home
