import React from 'react'
import type { Course } from '../data/mockData'

interface CourseCardProps {
  course: Course
  onClick?: () => void
}

export default function CourseCard({ course, onClick }: CourseCardProps) {
  return (
    <div
      onClick={onClick}
      className="group cursor-pointer rounded-lg overflow-hidden bg-white shadow-sm hover:-translate-y-0.5 hover:shadow-md transition-all duration-200"
    >
      {/* Thumbnail */}
      <div className={`relative aspect-video w-full bg-gradient-to-br ${course.gradClass}`}>
        <div className="flex h-full flex-col items-center justify-center px-4 text-center text-white">
          {course.type === 'free' && (
            <span className="mb-2 inline-block rounded bg-green-600 px-2 py-0.5 text-[11px] font-bold text-white">
              무료강의
            </span>
          )}
          {course.date && (
            <p className="mb-1 text-[11px] text-white/70">{course.date}</p>
          )}
          {course.description && (
            <p className="mb-2 text-[11px] text-white/70">{course.description}</p>
          )}
          <p className="text-[15px] font-black leading-snug whitespace-pre-line">{course.shortTitle}</p>
          {course.instructor && (
            <p className="mt-1.5 text-[11px] text-white/70">{course.instructor}</p>
          )}
        </div>

        {/* Badges */}
        {course.badges.length > 0 && (
          <div className="absolute top-2 left-2 flex gap-1">
            {course.badges.map(b => (
              <span
                key={b}
                className={`rounded px-1.5 py-0.5 text-[11px] font-bold text-white ${
                  b === 'HOT' ? 'bg-[#cc0000]' : 'bg-orange-500'
                }`}
              >
                {b}
              </span>
            ))}
          </div>
        )}

        {/* Go button */}
        <div className="absolute bottom-2 right-2 flex h-7 w-7 items-center justify-center rounded-full bg-white/90 text-xs font-bold text-gray-700">
          ↗
        </div>
      </div>

      {/* Info */}
      <div className="p-3.5">
        <p className="mb-1.5 text-[14px] font-semibold leading-snug line-clamp-2">{course.title}</p>
        <div className="flex flex-wrap gap-1.5 text-[12px] text-gray-500">
          {course.tags.map((tag, i) => (
            <span key={tag} className={i === 0 ? 'text-[#cc0000]' : ''}>{tag}</span>
          ))}
        </div>
      </div>
    </div>
  )
}
