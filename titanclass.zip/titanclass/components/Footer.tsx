import React from 'react'

const FOOTER_LINKS = ['타이탄클래스 카페', '타이탄철물점 블로그', '타이탄컴퍼니', '타이탄클래스 채용']

export default function Footer() {
  return (
    <footer className="bg-[#1a1a1a] text-gray-500">
      {/* Marquee */}
      <div className="overflow-hidden bg-[#111] py-4">
        <div className="flex gap-10 whitespace-nowrap animate-marquee">
          {[...Array(6)].map((_, i) => (
            <React.Fragment key={i}>
              <span className="text-3xl font-black text-white tracking-tight">YOUR SUCCESS</span>
              <span className="text-3xl font-black text-[#cc0000]">•</span>
            </React.Fragment>
          ))}
        </div>
      </div>

      <div className="mx-auto max-w-[1200px] px-10 py-12">
        <div className="mb-10 grid grid-cols-4 gap-10 border-b border-gray-700 pb-10">
          {/* Col 1 */}
          <div>
            <div className="mb-4 flex items-center gap-2">
              <div className="h-6 w-6 bg-[#cc0000]" style={{clipPath:'polygon(0 0,100% 0,100% 70%,50% 100%,0 70%)'}} />
              <span className="text-sm font-black text-white">TITAN CLASS</span>
            </div>
            {['클래스','타이탄은?','강사진','자주묻는질문'].map(l => (
              <a key={l} href="#" className="mb-2 block text-sm text-gray-500 hover:text-white transition-colors">{l}</a>
            ))}
          </div>
          {/* Col 2 */}
          <div>
            <h4 className="mb-4 text-sm font-semibold text-white">공지사항</h4>
            {['개인정보처리방침','이용약관'].map(l => (
              <a key={l} href="#" className="mb-2 block text-sm hover:text-white transition-colors">{l}</a>
            ))}
          </div>
          {/* Col 3 - Help */}
          <div>
            <div className="rounded-lg bg-[#222] p-6">
              <h4 className="mb-2 text-lg font-bold text-white">도움이<br/>필요하신가요?</h4>
              <p className="mb-4 text-[13px] leading-relaxed text-gray-500">
                성장에 목마른 모든 분들을 환영합니다. 타이탄클래스에 문의하실 내용이 있으시다면 언제든지 연락주세요.
              </p>
              <div className="flex cursor-pointer items-center justify-between rounded-md bg-[#333] px-4 py-3 text-[13px] text-gray-400 hover:bg-[#3a3a3a] transition-colors">
                <span>1:1 문의하기</span>
                <span className="text-[#cc0000]">›</span>
              </div>
            </div>
          </div>
          {/* Col 4 - External links */}
          <div>
            <div className="h-[14px] mb-4" />
            {FOOTER_LINKS.map(l => (
              <div key={l} className="mb-2 flex cursor-pointer items-center justify-between rounded-md bg-[#222] px-4 py-3 hover:bg-[#2a2a2a] transition-colors">
                <span className="text-[13px] text-gray-300">{l}</span>
                <span className="text-[#cc0000]">›</span>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom info */}
        <div className="space-y-1 text-[11px] text-gray-600">
          <p>주식회사 타이탄컴퍼니 | 대표이사: 오윤목 | 사업자번호: 409-86-55803 | 통신판매신고번호: 2025-서울강남-02444호</p>
          <p>원격평생교육원: 원격-434호 | 인증기관무상평생교육시설: 인-314인</p>
          <p>주소: 서울특별시 강남구 선릉로 611, 2층 (논현동) | 교육장: 서울특별시 강남구 선릉로 611, 2층 (논현동)</p>
          <p>대표전화번호: 1600-9605 | 이메일: titanclass@titanz.co.kr</p>
          <p className="mt-3 text-gray-500">2026 ⓒ SYSTEMNOVA</p>
        </div>
      </div>
    </footer>
  )
}
