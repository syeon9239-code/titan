import React, { useEffect, useState } from 'react'

interface KakaoLoginOverlayProps {
  onComplete: () => void
  onClose: () => void
}

const STEPS = [
  '카카오 계정 확인 중...',
  '회원 정보 불러오는 중...',
  '로그인 완료!',
]

export default function KakaoLoginOverlay({ onComplete, onClose }: KakaoLoginOverlayProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [doneSteps, setDoneSteps] = useState<number[]>([])

  useEffect(() => {
    const timers = [
      setTimeout(() => setCurrentStep(0), 100),
      setTimeout(() => { setDoneSteps([0]); setCurrentStep(1) }, 1000),
      setTimeout(() => { setDoneSteps([0,1]); setCurrentStep(2) }, 2000),
      setTimeout(() => { setDoneSteps([0,1,2]) }, 2800),
      setTimeout(() => onComplete(), 3200),
    ]
    return () => timers.forEach(clearTimeout)
  }, [onComplete])

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/60">
      <div className="w-[320px] rounded-2xl bg-white p-10 text-center shadow-2xl">
        {/* Logo */}
        <div className="mb-6 flex items-center justify-center gap-2">
          <div className="h-7 w-7 bg-[#cc0000]" style={{clipPath:'polygon(0 0,100% 0,100% 70%,50% 100%,0 70%)'}} />
          <span className="text-lg font-black">TITAN<span className="text-[#cc0000]">CLASS</span></span>
        </div>

        {/* Steps */}
        <div className="mb-6 text-left">
          {STEPS.map((label, i) => (
            <div
              key={i}
              className={`flex items-center gap-3 border-b border-gray-100 py-2.5 last:border-0 text-sm transition-colors duration-300 ${
                doneSteps.includes(i) ? 'text-gray-800' :
                currentStep === i ? 'font-semibold text-[#cc0000]' : 'text-gray-400'
              }`}
            >
              <div className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-bold transition-colors duration-300 ${
                doneSteps.includes(i) ? 'bg-green-500 text-white' :
                currentStep === i ? 'bg-yellow-300 text-gray-800' : 'bg-gray-100 text-gray-400'
              }`}>
                {doneSteps.includes(i) ? '✓' : i + 1}
              </div>
              {label}
            </div>
          ))}
        </div>

        {/* Spinner */}
        {doneSteps.length < 3 && (
          <div className="mx-auto h-9 w-9 rounded-full border-[3px] border-gray-100 border-t-yellow-300 spinner" />
        )}

        <p className="mt-2 text-xs text-gray-400">
          {doneSteps.length < 3 ? '카카오 계정으로 연결하는 중...' : '이동 중...'}
        </p>
      </div>
    </div>
  )
}
