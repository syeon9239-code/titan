import React from 'react'

interface LoginPageProps {
  onKakaoLogin: () => void
}

export default function LoginPage({ onKakaoLogin }: LoginPageProps) {
  return (
    <div className="flex min-h-[calc(100vh-97px)] items-center justify-center bg-neutral-600">
      <div className="w-[380px] rounded-2xl bg-white p-10 shadow-xl">
        {/* Logo */}
        <div className="mb-7 flex items-center gap-2">
          <div className="h-6 w-6 bg-[#cc0000]" style={{clipPath:'polygon(0 0,100% 0,100% 70%,50% 100%,0 70%)'}} />
          <span className="text-base font-black">TITAN<span className="text-[#cc0000]">CLASS</span></span>
        </div>

        {/* Kakao button */}
        <button
          onClick={onKakaoLogin}
          className="mb-5 flex w-full items-center justify-center gap-2 rounded-md bg-[#FEE500] py-3.5 text-[15px] font-semibold text-[#3C1E1E] hover:bg-yellow-400 transition-colors"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="#3C1E1E">
            <path d="M12 3C6.48 3 2 6.48 2 11c0 2.93 1.61 5.5 4.05 7.07L5 21l4.31-2.37C10.16 18.9 11.07 19 12 19c5.52 0 10-3.48 10-8S17.52 3 12 3z"/>
          </svg>
          카카오로 3초만에 시작하기
        </button>

        {/* ID/PW fields */}
        <input
          type="text"
          placeholder="아이디를 입력해주세요"
          className="mb-2.5 w-full rounded-md border border-gray-200 px-3.5 py-3 text-[14px] outline-none focus:border-[#cc0000] transition-colors font-[inherit]"
        />
        <input
          type="password"
          placeholder="비밀번호를 입력해주세요"
          className="mb-1 w-full rounded-md border border-gray-200 px-3.5 py-3 text-[14px] outline-none focus:border-[#cc0000] transition-colors font-[inherit]"
        />

        <button
          onClick={onKakaoLogin}
          className="mt-1 w-full rounded-md bg-[#cc0000] py-3.5 text-[15px] font-semibold text-white hover:bg-[#aa0000] transition-colors"
        >
          로그인
        </button>

        <div className="mt-4 flex justify-center gap-4 text-[13px] text-gray-400">
          <a href="#" className="hover:text-[#cc0000]">아이디 찾기</a>
          <a href="#" className="hover:text-[#cc0000]">비밀번호 찾기</a>
          <a href="#" className="hover:text-[#cc0000]">일반회원 가입하기</a>
        </div>
      </div>
    </div>
  )
}
