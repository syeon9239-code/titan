import React from 'react'
import dynamic from 'next/dynamic'
import CourseCard from '../CourseCard'
import SectionHeader from '../SectionHeader'
import { FREE_COURSES, PREMIUM_COURSES, VOD_COURSES, INSTRUCTORS, REVIEWS, CALENDAR_EVENTS } from '../../data/mockData'

const FireworksHero = dynamic(() => import('../FireworksHero'), { ssr: false })

interface HomePageProps {
  onNavigate: (page: string) => void
}

const DAYS_BEFORE = 5 // Feb starts on Saturday → 5 empty cells

export default function HomePage({ onNavigate }: HomePageProps) {
  const totalDays = 28

  return (
    <div>
      <FireworksHero onNavigate={onNavigate} />

      <div className="mx-auto max-w-[1200px] px-10">

        {/* FREE COURSES */}
        <section className="py-12">
          <SectionHeader icon="🔥" title="무료 강의" sub="Webinar" />
          <div className="grid grid-cols-3 gap-5">
            {FREE_COURSES.slice(0, 3).map(c => (
              <CourseCard key={c.id} course={c} onClick={() => onNavigate('free-detail')} />
            ))}
          </div>
        </section>

        {/* GIFT BANNER */}
        <div className="my-2 flex items-center justify-between rounded-xl px-10 py-7"
          style={{background:'linear-gradient(135deg,#1a1a2e,#0f3460)'}}>
          <div className="text-white">
            <h3 className="text-[18px] font-bold leading-snug">첫 만남 수강생 한정<br/>타이탄클래스가 준비한 특별 선물</h3>
          </div>
          <button className="rounded-md bg-[#cc0000] px-6 py-2.5 text-sm font-semibold text-white hover:bg-[#aa0000] transition-colors">
            지금 받기 →
          </button>
        </div>

        {/* PREMIUM */}
        <section className="py-12">
          <SectionHeader icon="🎁" title="프리미엄 강의" sub="Premium Lecture" />
          <div className="max-w-[400px]">
            {PREMIUM_COURSES.map(c => (
              <CourseCard key={c.id} course={c} onClick={() => onNavigate('premium')} />
            ))}
          </div>
        </section>

        {/* VOD */}
        <section className="py-12 pt-0">
          <SectionHeader icon="🔥" title="바로 들을 수 있는, VOD강의" sub="VOD Lecture" />
          <div className="grid grid-cols-2 gap-5">
            {VOD_COURSES.map(c => (
              <CourseCard key={c.id} course={c} onClick={() => onNavigate('vod')} />
            ))}
          </div>
        </section>
      </div>

      {/* SUCCESS REVIEWS */}
      <section className="bg-[#111] py-14">
        <div className="mx-auto max-w-[1200px] px-10">
          <h2 className="mb-6 flex items-center gap-2 text-xl font-bold text-white">
            <span>🏆</span> 수강생 수익화 사례 <span className="text-sm font-normal text-gray-600 ml-1">Success Stories</span>
          </h2>
          <div className="grid grid-cols-3 gap-4">
            {REVIEWS.map(r => (
              <div key={r.id} className="rounded-lg bg-[#1e1e1e] p-5">
                <p className="mb-2.5 text-[13px] text-gray-500">{r.name} • {r.category}</p>
                <p className="text-[13px] leading-relaxed text-gray-300">{r.text}</p>
                <p className="mt-2.5 text-[11px] text-gray-600">{r.date}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-[1200px] px-10">
        {/* CALENDAR */}
        <section className="py-12">
          <div className="mb-6 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-xl font-bold">
              <span>🔥</span> 이달의 무료강의 일정 <span className="text-sm font-normal text-gray-400 ml-1">Schedule</span>
            </h2>
            <div className="flex items-center gap-3 text-[13px] text-gray-500">
              <span className="flex items-center gap-1.5">
                <span className="inline-block h-2.5 w-2.5 rounded-full bg-[#cc0000]" />강의 예정
              </span>
            </div>
          </div>
          <p className="mb-4 text-[28px] font-black tracking-tight text-gray-900">FEBRUARY</p>

          <div className="overflow-hidden rounded-lg border border-gray-200">
            {/* Header */}
            <div className="grid grid-cols-7 bg-gray-50">
              {['일','월','화','수','목','금','토'].map(d => (
                <div key={d} className="border-b border-r border-gray-200 p-2.5 text-center text-[12px] font-semibold text-gray-500 last:border-r-0">{d}</div>
              ))}
            </div>
            {/* Weeks */}
            {Array.from({length: Math.ceil((DAYS_BEFORE + totalDays) / 7)}).map((_, weekIdx) => (
              <div key={weekIdx} className="grid grid-cols-7">
                {Array.from({length: 7}).map((_, dayIdx) => {
                  const cellIdx = weekIdx * 7 + dayIdx
                  const day = cellIdx - DAYS_BEFORE + 1
                  const valid = day >= 1 && day <= totalDays
                  const event = CALENDAR_EVENTS.find(e => e.day === day)
                  const isToday = day === 22

                  return (
                    <div key={dayIdx} className={`min-h-[80px] border-b border-r border-gray-200 p-2 last:border-r-0 ${!valid ? 'bg-gray-50' : 'bg-white'}`}>
                      {valid && (
                        <>
                          <div className={`mb-1 text-[13px] font-semibold ${isToday ? 'flex h-[22px] w-[22px] items-center justify-center rounded-full bg-[#cc0000] text-[12px] text-white' : 'text-gray-700'}`}>
                            {day}
                          </div>
                          {event && (
                            <div className={`rounded px-1.5 py-0.5 text-[10px] leading-tight ${event.color} ${event.textColor}`}>
                              {event.text}
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  )
                })}
              </div>
            ))}
          </div>
        </section>

        {/* INSTRUCTORS */}
        <section className="py-12 pt-0">
          <SectionHeader icon="🔥" title="엄노직업 수익화 전문가, 타이탄 강사진" showNav={false} />
          <div className="grid grid-cols-5 gap-5">
            {INSTRUCTORS.map(inst => (
              <div key={inst.id} className="cursor-pointer text-center group">
                <div className={`mb-2.5 aspect-square w-full overflow-hidden rounded-xl bg-gradient-to-br ${inst.gradClass} flex items-center justify-center text-5xl`}>
                  {inst.emoji}
                </div>
                <p className="text-[14px] font-semibold group-hover:text-[#cc0000] transition-colors">{inst.name}</p>
                <p className="text-[12px] text-gray-500">{inst.tag}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}
