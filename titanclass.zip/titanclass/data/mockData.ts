// ── Types ──────────────────────────────────────────────────────────────────

export type Badge = 'HOT' | 'NEW'
export type CourseType = 'free' | 'premium' | 'vod'

export interface Course {
  id: string
  title: string
  shortTitle: string
  instructor: string
  tags: string[]
  badges: Badge[]
  type: CourseType
  date?: string
  gradClass: string
  description?: string
}

export interface Instructor {
  id: string
  name: string
  tag: string
  gradClass: string
  emoji: string
}

export interface Review {
  id: string
  name: string
  category: string
  text: string
  date: string
}

export interface CalendarEvent {
  day: number
  text: string
  color: string // tailwind bg class
  textColor: string
  isToday?: boolean
}

// ── Data ───────────────────────────────────────────────────────────────────

export const FREE_COURSES: Course[] = [
  {
    id: 'gutabari-shorts',
    title: '[구타바리] 1분짜리 영화쇼츠로 월1천만원 벌기 무료특강',
    shortTitle: '1분짜리 영화쇼츠로\n월 1천만원 벌기',
    instructor: '구타바리',
    tags: ['구타바리', '유튜브'],
    badges: ['HOT', 'NEW'],
    type: 'free',
    date: '2월 22일 (일) PM7시 30분',
    gradClass: 'from-[#1a1a2e] to-[#cc0000]',
  },
  {
    id: 'ai-shortform',
    title: '[살이] 편집 못해도 가능한 AI 쇼폼 대행 실전 강의 무료특강',
    shortTitle: '편집 못해도 가능한\nAI 쇼폼 대행 실전',
    instructor: '살이',
    tags: ['살이', 'SNS'],
    badges: ['NEW'],
    type: 'free',
    date: '2월 24일 (월) PM7시 30분',
    gradClass: 'from-[#0f3460] to-[#533483]',
  },
  {
    id: 'patriot-youtube',
    title: '[애삼이] 애국 유튜브로 노후연금 준비하기 무료특강',
    shortTitle: '애국 유튜브로\n노후연금 준비하기',
    instructor: '애삼이',
    tags: ['애삼이', '유튜브'],
    badges: ['NEW'],
    type: 'free',
    date: '2월 25일 (화) PM7시 30분',
    gradClass: 'from-[#1a472a] to-[#2d6a4f]',
  },
  {
    id: 'no-face-pd',
    title: '[유튜브소츠] 얼굴공개 없이 유튜브파워난로 연설비기 무료특강',
    shortTitle: '얼굴공개 없이\nPD로 본벌기',
    instructor: '선텐소츠',
    tags: ['선텐소츠', '유튜브'],
    badges: ['HOT', 'NEW'],
    type: 'free',
    date: '3월 1일 (일) PM7시 30분',
    gradClass: 'from-[#1e3a5f] to-[#0f3460]',
  },
  {
    id: 'money-youtube',
    title: '[유튜브] 2025년 돈 벌어다는 사시어 돈을 무료공개',
    shortTitle: '\'돈\'주제로\n쓸어담는\n유튜브 수익화',
    instructor: '쯔들이',
    tags: ['쯔들이', '유튜브'],
    badges: ['NEW'],
    type: 'free',
    date: '3월 12일 (수) PM7시 30분',
    gradClass: 'from-[#0f3460] to-[#533483]',
  },
  {
    id: 'shorts-alliin',
    title: '[소츠마제] 2025 소츠이제의 New유튜브 수익화 올인원 로드맵',
    shortTitle: '소츠이제의\nNew유튜브\n올인원 로드맵',
    instructor: '소츠마제',
    tags: ['소츠마제', '유튜브'],
    badges: ['HOT', 'NEW'],
    type: 'free',
    date: '3월 25일 (화) PM7시 30분',
    gradClass: 'from-[#3a1c71] via-[#d76d77] to-[#ffaf7b]',
  },
]

export const PREMIUM_COURSES: Course[] = [
  {
    id: 'health-food',
    title: '[최대패] 초보라도 가능한 월 2억 만드는 건강식품 제조 1기',
    shortTitle: '월 2억 만드는\n건강식품 제조 특강!',
    instructor: '최대패',
    tags: ['최대패', '커머스'],
    badges: ['NEW'],
    type: 'premium',
    gradClass: 'from-[#0a1628] to-[#1e3a5f]',
    description: '한정인원 모집 중',
  },
]

export const VOD_COURSES: Course[] = [
  {
    id: 'final-lecture',
    title: '성공하는 사람들의 비밀 파이널특강',
    shortTitle: '파이널특강',
    instructor: '내일은',
    tags: ['내일은', '판매계'],
    badges: ['HOT'],
    type: 'vod',
    gradClass: 'from-[#111] to-[#333]',
  },
  {
    id: 'youtube-start',
    title: '생존을 위한 하나의 선택 유튜브 통품 시작하기',
    shortTitle: '유튜브 통품\n시작하기',
    instructor: '자생업',
    tags: ['자생업', '유튜브'],
    badges: ['HOT'],
    type: 'vod',
    gradClass: 'from-[#0a1628] to-[#1e3a5f]',
  },
]

export const INSTRUCTORS: Instructor[] = [
  { id: '1', name: '구타바리', tag: '유튜브 쇼츠',    gradClass: 'from-[#1a1a2e] to-[#333]', emoji: '👨' },
  { id: '2', name: '살이',    tag: 'SNS 마케팅',    gradClass: 'from-[#0f3460] to-[#533483]', emoji: '👩' },
  { id: '3', name: '최대패',  tag: '건강식품 제조',  gradClass: 'from-[#1a472a] to-[#2d6a4f]', emoji: '👨' },
  { id: '4', name: '내일은',  tag: '판매',          gradClass: 'from-[#5c4033] to-[#8d6e63]', emoji: '👩' },
  { id: '5', name: '자생업',  tag: '유튜브 통품',   gradClass: 'from-[#0d47a1] to-[#1565c0]', emoji: '👨' },
]

export const REVIEWS: Review[] = [
  {
    id: '1',
    name: '수강생 A',
    category: '유튜브 쇼츠',
    text: '처음에는 반신반의했는데 강의 들은 지 2달 만에 수익이 나기 시작했어요. 매달 꾸준히 늘어나고 있습니다. 정말 감사해요.',
    date: '2024.01.15',
  },
  {
    id: '2',
    name: '수강생 B',
    category: 'SNS 마케팅',
    text: '강의 내용이 정말 실전적이에요. 이론보다 바로 적용할 수 있는 노하우들을 전달해줘서 시작이 훨씬 쉬웠습니다.',
    date: '2024.02.03',
  },
  {
    id: '3',
    name: '수강생 C',
    category: '건강식품 제조',
    text: '월 2억은 아직이지만 이미 부업으로 월 500 이상 벌고 있습니다. 강사님 말씀대로 하나씩 따라가고 있어요!',
    date: '2024.02.10',
  },
]

export const CALENDAR_EVENTS: CalendarEvent[] = [
  { day: 11, text: '🔴 타입소 라이브강의',           color: 'bg-red-50',  textColor: 'text-red-600' },
  { day: 22, text: 'PM7:30 영화쇼츠로 월천만원',     color: 'bg-red-50',  textColor: 'text-red-600', isToday: true },
  { day: 24, text: 'PM7:30 AI 쇼폼 대행 실전',       color: 'bg-blue-50', textColor: 'text-blue-600' },
  { day: 25, text: 'PM7:30 애국 유튜브로 노후연금',   color: 'bg-blue-50', textColor: 'text-blue-600' },
]
