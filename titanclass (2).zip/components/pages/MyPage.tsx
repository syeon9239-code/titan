import React, { useState } from 'react'

interface MyPageProps {
  onNavigate: (page: string) => void
  onLogout: () => void
}

const MENU_ITEMS = [
  { label: '내 강의실', isHeader: true },
  { label: '수강중인 강의', tab: 'ongoing' },
  { label: '완료한 강의',   tab: 'completed' },
  { label: '전체',          tab: 'all' },
  { label: '메뉴', isHeader: true },
  { label: '오픈알림' },
  { label: '무료강의' },
  { label: '전자책' },
  { label: 'VOD 강의' },
  { label: '쿠폰목록' },
  { label: '위시리스트' },
  { label: '주문결제내역' },
  { label: '회원정보관리' },
]

export default function MyPage({ onNavigate, onLogout }: MyPageProps) {
  const [activeTab, setActiveTab] = useState<'ongoing'|'completed'|'all'>('ongoing')

  return (
    <div>
      {/* Hero */}
      <div className="relative h-40 overflow-hidden bg-gradient-to-br from-[#1a1a2e] to-[#0f3460]">
        <div className="mx-auto flex h-full max-w-[1200px] items-center px-10">
          <h1 className="text-[28px] font-black text-white">마이페이지</h1>
        </div>
        <div className="absolute right-20 top-1/2 -translate-y-1/2 text-[80px] opacity-20">📋</div>
      </div>

      <div className="mx-auto max-w-[1200px] px-10">
        <div className="grid grid-cols-[240px_1fr] gap-10 py-10">

          {/* Sidebar */}
          <div>
            {/* User info */}
            <div className="mb-6 text-center">
              <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-[#cc0000] text-2xl text-white overflow-hidden">
                👤
              </div>
              <p className="mb-2 text-[16px] font-bold">박시연</p>
              <div className="flex justify-center gap-4 text-[12px] text-gray-400">
                <span>수강중인 강의 <span className="font-semibold text-gray-700">0</span></span>
                <span>완료한 강의 <span className="font-semibold text-gray-700">0</span></span>
                <span>쿠폰 <span className="font-semibold text-gray-700">0</span></span>
              </div>
            </div>

            {/* Menu */}
            <div className="overflow-hidden rounded-lg border border-gray-200">
              {MENU_ITEMS.map((item, i) => {
                if (item.isHeader) {
                  return (
                    <div key={i} className="border-b border-gray-200 bg-gray-50 px-4 py-3 text-[13px] font-semibold text-gray-500">
                      {item.label}
                    </div>
                  )
                }
                const isActive = item.tab === activeTab
                return (
                  <button
                    key={i}
                    onClick={() => { if (item.tab) setActiveTab(item.tab as any) }}
                    className={`flex w-full items-center border-b border-gray-200 px-4 py-3 text-left text-[14px] transition-colors hover:bg-gray-50 last:border-b-0 ${isActive ? 'font-medium text-[#cc0000]' : 'text-gray-700'}`}
                  >
                    {item.label}
                  </button>
                )
              })}
              <button
                onClick={() => { onLogout(); onNavigate('home') }}
                className="flex w-full items-center px-4 py-3 text-left text-[14px] font-medium text-[#cc0000] hover:bg-gray-50 transition-colors"
              >
                로그아웃
              </button>
            </div>
          </div>

          {/* Content */}
          <div>
            {/* Study room tabs */}
            <div className="mb-6 flex border-b-2 border-gray-200">
              {(['ongoing','completed','all'] as const).map(t => {
                const label = t==='ongoing'?'수강중인 강의':t==='completed'?'완료한 강의':'전체'
                return (
                  <button
                    key={t}
                    onClick={() => setActiveTab(t)}
                    className={`px-6 py-3 text-[14px] font-medium border-b-2 -mb-0.5 transition-colors ${
                      activeTab === t ? 'border-[#cc0000] text-[#cc0000]' : 'border-transparent text-gray-500 hover:text-gray-800'
                    }`}
                  >
                    {label}
                  </button>
                )
              })}
            </div>

            {/* Empty state */}
            <div className="flex items-center justify-center rounded-lg border border-gray-200 py-20 text-[14px] text-gray-400">
              강의가 없습니다.
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
